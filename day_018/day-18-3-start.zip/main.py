import turtle as t

tim = t.Turtle()

########### Challenge 3 - Draw Shapes ########