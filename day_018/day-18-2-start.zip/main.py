import turtle as t

tim = t.Turtle()

########### Challenge 2 - Draw a Dashed Line ########