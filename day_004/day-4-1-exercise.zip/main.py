#Write your code below this line 👇
#Hint: Remember to import the random module first. 🎲










