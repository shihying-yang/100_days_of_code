number = int(input("Which number do you want to check?"))

#Remember that single "=" is assignment.
#Double "==" is checkinging for equality.
if number % 2 == 0:
  print("This is an even number.")
else:
  print("This is an odd number.")
  
