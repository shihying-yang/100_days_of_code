# Create the logging_decorator() function 👇



# Use the decorator 👇